#include <iostream>

int main() {
    std::cout << "Hello CMake!" << std::endl;
    return 0;
}