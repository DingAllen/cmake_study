cmake .
make
rm -r CMakeFiles
rm CMakeCache.txt
rm cmake_install.cmake
rm Makefile